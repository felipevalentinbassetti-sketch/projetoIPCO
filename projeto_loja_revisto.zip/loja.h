#ifndef LOJA_H
#define LOJA_H

// Estrutura para representar os jogos cadastrados
struct Jogo {
    char nome[50];
    char genero[30];
    float preco;
    int classificacao;
    int downloads;
};

// Prototipos das funcoes sem uso de ponteiros nos parametros
int carregarJogos(struct Jogo vetorJogos[]);
int cadastrarJogo(struct Jogo vetorJogos[], int totalJogos);
void registrarCompra(struct Jogo vetorJogos[], int totalJogos);
void exibirRelatorios(struct Jogo vetorJogos[], int totalJogos);
void salvarJogos(struct Jogo vetorJogos[], int totalJogos);
void gerenciarAvaliacoes(struct Jogo vetorJogos[], int totalJogos, int matrizAvaliacoes[][100], int qtdAvaliacoesPorJogo[]);

#endif
